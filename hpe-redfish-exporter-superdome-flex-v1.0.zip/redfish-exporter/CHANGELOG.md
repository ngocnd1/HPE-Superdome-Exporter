# Changelog

## 0.4.0

- Thêm compatibility path cho HPE Superdome Flex legacy
  `Chassis/Thermal` và `Chassis/Power`.
- Xuất fan health/RPM và PSU health/input/output watt từ `MemberId` mà vẫn giữ
  nguyên metric contract của SC3200.
- Chọn schema theo capability và theo metric family; schema mới được ưu tiên và
  không sinh duplicate series trên firmware hybrid.
- Fallback `physical_context="Fan"` cho fan legacy không công bố context.
- Thêm unit test schema legacy/hybrid và replay xác minh trên payload Superdome
  Flex đã khử bí mật.
- Thêm systemd template chạy hai instance SC3200/Superdome Flex, config mẫu và
  hai job vmagent interval 1 phút.
- Thêm `install-superdome-flex-isolated.sh` để cài Superdome Flex vào virtualenv,
  config, service và port riêng mà không thay đổi SC3200 đang chạy.
- Dashboard cooling/power health hoạt động với cả subsystem mới và resource
  fan/PSU legacy.
- Capture tool bỏ qua `DebugLogs` để giảm nguy cơ lộ định danh trong tên file
  debug.
