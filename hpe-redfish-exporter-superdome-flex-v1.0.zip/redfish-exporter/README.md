# HPE RMC Redfish Exporter

[![CI](https://github.com/OWNER/REPOSITORY/actions/workflows/ci.yml/badge.svg)](https://github.com/OWNER/REPOSITORY/actions/workflows/ci.yml)

Python Prometheus exporter cho HPE Compute Scale-up Server 3200 và HPE
Superdome Flex RMC. Exporter chỉ dùng HTTPS GET, ưu tiên Redfish `$expand=.` và
tự fallback khi firmware không hỗ trợ expand.

## Hai platform, một source code

Không có fork riêng theo model. Phần HTTP, discovery, inventory, health,
Prometheus metric và dashboard dùng chung. Collector chọn parser theo capability
mà từng `Chassis` công bố:

| Platform đã kiểm tra | Telemetry path | Fan/PSU health và watt |
|---|---|---|
| Scale-up 3200 | `Sensors` | `ThermalSubsystem`, `PowerSubsystem` |
| Superdome Flex | `Thermal` | embedded `Fans` và `PowerSupplies` trong `Thermal`/`Power` |

Nếu firmware công bố cả hai schema, exporter ưu tiên schema mới theo từng metric
family và không xuất hai time series trùng nhau. Việc tách hai systemd instance
chỉ để cô lập timeout/restart/port; binary và source code vẫn giống 100%.

## Metric contract v0.4

- `redfish_up`, `redfish_scrape_duration_seconds`
- `redfish_resource_health`, `redfish_resource_power_state`
- `redfish_system_info`, `redfish_chassis_info`, `redfish_manager_info`
- `redfish_system_processor_count`, `redfish_system_logical_processor_count`, `redfish_system_memory_bytes`
- `redfish_temperature_celsius`, `redfish_fan_speed_rpm`, `redfish_chassis_power_input_watts`
- `redfish_sensor_ratio`, `redfish_sensor_power_watts`, `redfish_sensor_voltage_volts`
- `redfish_power_supply_input_watts`, `redfish_power_supply_output_watts`

Health giữ đúng quy ước hiện tại: `OK=1`, `Warning=0.5`, `Critical=0`,
`Unknown=-1`. Xem đầy đủ label và PromQL tại [docs/METRICS.md](docs/METRICS.md).

## Cài đặt khuyến nghị

Nếu SC3200 đang chạy và không được phép tác động, dùng installer cô lập:

```bash
PYTHON_BIN="$(command -v python3.14 || command -v python3)"
sudo ./deployment/install-superdome-flex-isolated.sh --python "$PYTHON_BIN"
```

Script không sửa virtualenv, config, service hoặc port 9610 của SC3200 và không
tự start Superdome Flex trước khi bạn thay placeholder credential.

Với máy cài mới hoàn toàn, có thể dùng installer tổng quát:

```bash
sudo ./deployment/install.sh
```

Sau đó làm theo [deployment/README.md](deployment/README.md) để chạy:

- `redfish-exporter@sc3200` ở port 9610;
- `redfish-exporter@superdome-flex` ở port 9611;
- hai job vmagent có `scrape_interval: 1m`, `scrape_timeout: 55s`.

Năm dashboard JSON dùng datasource VictoriaMetrics nằm trong
`grafana/dashboards/`. Dashboard dùng biến `target` và `chassis`, nên tự nhận
RMC mới nếu `target.name` là duy nhất.

Service đơn của bản cũ vẫn được giữ để nâng cấp không bị bắt buộc đổi kiến trúc.
Nếu chỉ chạy một RMC, có thể tiếp tục dùng `/etc/redfish-exporter/config.yml` và
`redfish-exporter.service`.

## Kiểm thử

```bash
python3 -m venv .venv
.venv/bin/pip install -e '.[dev]'
.venv/bin/pytest
```

Smoke test bằng DMTF Redfish Mockup Server, không cần Docker:

```bash
chmod +x scripts/test-with-dmtf-mockup.sh
./scripts/test-with-dmtf-mockup.sh
```

Để replay mockup đã capture:

```bash
python tools/capture_to_mockup.py rmc-payload rmc-mockup
./scripts/test-with-dmtf-mockup.sh rmc-mockup
```

Unit test có fixture tối thiểu cho cả schema mới và legacy, đồng thời kiểm tra
firmware hybrid không sinh duplicate series.

## TLS và credential

Mỗi target phải dùng địa chỉ `https://`. Với CA nội bộ, cấu hình `ca_file` là
phương án production. `verify_tls: false` chỉ dành cho certificate self-signed
khi kiểm thử; client sẽ tắt riêng cảnh báo `InsecureRequestWarning` trong mode
này. Nên dùng account Redfish chỉ đọc và đặt password qua `password_env`.

## Payload để mở rộng sau này

Đọc [docs/RMC_PAYLOAD.md](docs/RMC_PAYLOAD.md) và dùng
`tools/capture_redfish_payload.py`. Script chỉ GET, bỏ qua account, log/debug,
certificate và network config, đồng thời che các trường nhận dạng phổ biến.
Vẫn phải kiểm tra thủ công `Name` trước khi chia sẻ vì một số RMC nhúng service
ID vào tên resource.

## Lưu ý dữ liệu Superdome Flex

Payload đã kiểm tra có fan RPM và PSU input/output watt ở schema legacy. Một số
sensor CPU mang tên `P*_THROT_OFFSET`; đây là thermal offset do RMC trả, không
nên hiển thị như nhiệt độ die tuyệt đối. Dashboard có thể phân loại bằng
`physical_context` và `sensor_name` mà không cần đổi metric contract.
