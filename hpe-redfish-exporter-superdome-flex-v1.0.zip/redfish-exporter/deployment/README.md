# Deployment bundle

## Đang có SC3200 chạy: dùng installer cô lập

Nếu `redfish-exporter.service` cho SC3200 đang chạy ổn định, **không chạy**
`deployment/install.sh` và không chuyển SC3200 sang template service trong cùng
lần triển khai. Hai việc đó thay đổi virtualenv hoặc service hiện tại.

Dùng script riêng dưới đây. Nó chỉ cài virtualenv, config, unit và port dành cho
Superdome Flex; script không stop/restart/nâng cấp SC3200 và không tự start dịch
vụ mới khi config vẫn còn placeholder:

```bash
sudo mkdir -p /opt/superdome-redfish-exporter
sudo unzip hpe-redfish-exporter-v0.4.0-sc3200-superdome-flex.zip \
  -d /opt/superdome-redfish-exporter
cd /opt/superdome-redfish-exporter/redfish-exporter
```

```bash
PYTHON_BIN="$(command -v python3.14 || command -v python3)"
sudo ./deployment/install-superdome-flex-isolated.sh --python "$PYTHON_BIN"
```

Các path được tạo:

| Thành phần | Superdome Flex cô lập |
|---|---|
| Virtualenv | `/opt/superdome-redfish-exporter/venv` |
| Config | `/etc/superdome-redfish-exporter/config.yml` |
| Password env | `/etc/superdome-redfish-exporter/secrets.env` |
| systemd | `superdome-redfish-exporter.service` |
| Port | `9611` |

Sau khi sửa hai file cấu hình:

```bash
sudo systemctl enable --now superdome-redfish-exporter
curl -fsS http://127.0.0.1:9611/metrics | grep '^redfish_'
```

Phần bên dưới dành cho triển khai mới hoặc khi chủ động chuyển cả hai platform
sang mô hình template; không cần thực hiện để bổ sung Superdome Flex cô lập.

## Mô hình khuyến nghị: cùng code, hai service instance

SC3200 và Superdome Flex dùng **chung một package Python**. Collector tự chọn
schema theo các link Redfish mà RMC công bố; không kiểm tra tên model. Tách hai
process systemd chỉ để cô lập timeout, restart, port và lịch scrape:

| Instance | Config | Port | Schema chính |
|---|---|---:|---|
| `redfish-exporter@sc3200` | `sc3200.yml` + `sc3200.env` | 9610 | `Sensors`, `ThermalSubsystem`, `PowerSubsystem` |
| `redfish-exporter@superdome-flex` | `superdome-flex.yml` + `superdome-flex.env` | 9611 | `Thermal`, `Power` legacy |

Nếu một process gặp RMC chậm hoặc lỗi xác thực, process còn lại vẫn phục vụ
vmagent. Không copy/fork source code cho từng dòng máy.

## Cài package

```bash
sudo ./deployment/install.sh
```

Script vẫn cài service đơn `redfish-exporter.service` để tương thích bản cũ,
đồng thời cài template `redfish-exporter@.service` dùng cho mô hình hai instance.

## Tạo cấu hình hai instance

```bash
sudo install -o root -g redfish-exporter -m 0640 \
  deployment/config/sc3200.yml.example /etc/redfish-exporter/sc3200.yml
sudo install -o root -g redfish-exporter -m 0640 \
  deployment/config/sc3200.env.example /etc/redfish-exporter/sc3200.env

sudo install -o root -g redfish-exporter -m 0640 \
  deployment/config/superdome-flex.yml.example /etc/redfish-exporter/superdome-flex.yml
sudo install -o root -g redfish-exporter -m 0640 \
  deployment/config/superdome-flex.env.example /etc/redfish-exporter/superdome-flex.env
```

Sửa bốn file trên. Mỗi `address` phải bắt đầu bằng `https://`. Password có thể
đặt trực tiếp bằng khóa `password`, nhưng `password_env` trong file `.env` an
toàn và dễ phân quyền hơn. Với CA nội bộ, ưu tiên `ca_file`; chỉ dùng
`verify_tls: false` khi đang kiểm thử certificate self-signed.

`target.name` phải duy nhất trên toàn bộ hai instance vì nó trở thành label
`target` trong VictoriaMetrics. Không đổi tên sau khi đã có dữ liệu lịch sử.

## Khởi động và kiểm tra

```bash
sudo systemctl disable --now redfish-exporter 2>/dev/null || true
sudo systemctl daemon-reload
sudo systemctl enable --now redfish-exporter@sc3200
sudo systemctl enable --now redfish-exporter@superdome-flex

systemctl status redfish-exporter@sc3200 redfish-exporter@superdome-flex
curl -fsS http://127.0.0.1:9610/metrics | grep '^redfish_'
curl -fsS http://127.0.0.1:9611/metrics | grep '^redfish_'
```

Kiểm tra nhanh các metric legacy vừa bổ sung:

```bash
curl -fsS http://127.0.0.1:9611/metrics | \
  grep -E '^redfish_(fan_speed_rpm|power_supply_(input|output)_watts|resource_health)'
```

Superdome Flex phải có `resource_type="fan"` và
`resource_type="power_supply"`; fan RPM có `physical_context="Fan"` nếu RMC
không trả PhysicalContext.

## Thêm nhiều RMC

Thêm entry vào `targets` của đúng file platform. Các target trong cùng instance
được scrape song song đến giới hạn `workers`. Sau đó:

```bash
sudo systemctl restart redfish-exporter@sc3200
# hoặc
sudo systemctl restart redfish-exporter@superdome-flex
```

## vmagent: chu kỳ 1 phút

Ghép `deployment/vmagent/redfish-dual-instance.yml` vào `scrape_configs` của
vmagent rồi reload/restart vmagent. Mỗi exporter có job riêng và label tĩnh
`platform`, nhưng dashboard vẫn lọc chính bằng label metric `target` và
`chassis_id`.

Với `scrape_interval: 1m`, giữ `scrape_timeout` nhỏ hơn 1 phút. Mẫu dùng 55 giây.
Sau khi chạy, xác minh:

```promql
redfish_up
```

```promql
max_over_time(redfish_scrape_duration_seconds[15m])
```

Nếu duration thường xuyên trên 50 giây thì tăng interval; không đặt timeout lớn
hơn interval. Việc tách instance không tự làm một RMC nhanh hơn, nhưng ngăn RMC
chậm ảnh hưởng endpoint của platform còn lại.

## Grafana + VictoriaMetrics

Yêu cầu plugin datasource VictoriaMetrics:

```bash
grafana cli plugins install victoriametrics-metrics-datasource
```

Nếu datasource đã tồn tại, không dùng file datasource mẫu. Mỗi dashboard có
biến datasource nên khi import hãy chọn datasource VictoriaMetrics hiện hữu.

Provisioning file layout:

```text
/etc/grafana/provisioning/dashboards/redfish.yml
/var/lib/grafana/dashboards/redfish/*.json
```

Copy và restart Grafana:

```bash
sudo install -m 0644 deployment/grafana/provisioning/dashboards/redfish.yml \
  /etc/grafana/provisioning/dashboards/redfish.yml
sudo install -d -m 0755 /var/lib/grafana/dashboards/redfish
sudo install -m 0644 grafana/dashboards/*.json /var/lib/grafana/dashboards/redfish/
sudo systemctl restart grafana-server
```

Dashboard fleet tự thấy RMC mới thông qua label `target`. Dashboard chi tiết
dùng biến `target` và `chassis`; không cần sửa JSON khi thêm target.
