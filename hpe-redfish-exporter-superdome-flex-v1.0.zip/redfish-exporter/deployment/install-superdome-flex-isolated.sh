#!/usr/bin/env bash
set -euo pipefail

# Install Superdome Flex beside an existing SC3200 exporter.  This script
# deliberately does not modify any of these existing SC3200 paths/resources:
#   /opt/redfish-exporter/venv
#   /etc/redfish-exporter/config.yml
#   /etc/redfish-exporter/secrets.env
#   redfish-exporter.service
#   TCP port 9610

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source_dir="$(cd "$script_dir/.." && pwd)"
install_dir="/opt/superdome-redfish-exporter"
config_dir="/etc/superdome-redfish-exporter"
service_file="/etc/systemd/system/superdome-redfish-exporter.service"
python_bin="python3"

usage() {
  cat <<'EOF'
Usage:
  sudo ./deployment/install-superdome-flex-isolated.sh
  sudo ./deployment/install-superdome-flex-isolated.sh --python /absolute/path/python3.14

The script installs an isolated virtualenv and service, but does not start it.
You must edit config.yml and secrets.env before enabling the service.
EOF
}

while (($#)); do
  case "$1" in
    --python)
      if (($# < 2)); then
        echo "--python requires a path" >&2
        exit 2
      fi
      python_bin="$2"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

if [[ $EUID -ne 0 ]]; then
  echo "Run this script with sudo/root." >&2
  exit 1
fi

if [[ ! -f "$source_dir/pyproject.toml" ]]; then
  echo "Cannot find pyproject.toml under $source_dir" >&2
  exit 1
fi

if [[ "$python_bin" != /* ]]; then
  python_bin="$(command -v "$python_bin" || true)"
fi
if [[ -z "$python_bin" || ! -x "$python_bin" ]]; then
  echo "Python executable not found. Pass --python /absolute/path/python3" >&2
  exit 1
fi

if ! "$python_bin" -c 'import sys; raise SystemExit(sys.version_info < (3, 10))'; then
  echo "Python 3.10 or newer is required: $python_bin" >&2
  exit 1
fi

if ! id redfish-exporter >/dev/null 2>&1; then
  useradd --system --home /nonexistent --shell /usr/sbin/nologin redfish-exporter
fi

install -d -o root -g root -m 0755 "$install_dir"
install -d -o root -g redfish-exporter -m 0750 "$config_dir"

if [[ ! -x "$install_dir/venv/bin/python" ]]; then
  "$python_bin" -m venv "$install_dir/venv"
fi

"$install_dir/venv/bin/python" -m pip install --upgrade "$source_dir"
install -o root -g root -m 0644 "$source_dir/README.md" "$install_dir/README.md"

# Existing operator configuration is never overwritten during an upgrade.
if [[ ! -f "$config_dir/config.yml" ]]; then
  install -o root -g redfish-exporter -m 0640 \
    "$source_dir/deployment/config/superdome-flex-isolated.yml.example" \
    "$config_dir/config.yml"
fi
if [[ ! -f "$config_dir/secrets.env" ]]; then
  install -o root -g redfish-exporter -m 0640 \
    "$source_dir/deployment/config/superdome-flex-isolated.env.example" \
    "$config_dir/secrets.env"
fi

install -o root -g root -m 0644 \
  "$source_dir/deployment/systemd/superdome-redfish-exporter.service" \
  "$service_file"

systemctl daemon-reload

cat <<EOF

Superdome Flex exporter installed in isolation.

SC3200 was not stopped, restarted, upgraded or reconfigured.

Next steps:
  1. Edit $config_dir/config.yml
  2. Edit $config_dir/secrets.env
  3. Run:
       systemctl enable --now superdome-redfish-exporter
  4. Verify:
       curl -fsS http://127.0.0.1:9611/metrics | grep '^redfish_'

The installer intentionally did not start the service while placeholder
credentials are still present.
EOF
