#!/usr/bin/env bash
set -euo pipefail

source_dir="$(cd "$(dirname "$0")/.." && pwd)"
install_dir="/opt/redfish-exporter"
config_dir="/etc/redfish-exporter"

if [[ $EUID -ne 0 ]]; then echo "Run with sudo/root" >&2; exit 1; fi
id redfish-exporter >/dev/null 2>&1 || useradd --system --home /nonexistent --shell /usr/sbin/nologin redfish-exporter
install -d -o root -g redfish-exporter -m 0750 "$install_dir" "$config_dir"
python3 -m venv "$install_dir/venv"
"$install_dir/venv/bin/pip" install --upgrade pip
"$install_dir/venv/bin/pip" install --upgrade "$source_dir"
install -o root -g root -m 0644 "$source_dir/README.md" "$install_dir/README.md"
if [[ ! -f "$config_dir/config.yml" ]]; then
  install -o root -g redfish-exporter -m 0640 "$source_dir/deployment/config/config.example.yml" "$config_dir/config.yml"
fi
if [[ ! -f "$config_dir/secrets.env" ]]; then
  install -o root -g redfish-exporter -m 0640 "$source_dir/deployment/config/secrets.env.example" "$config_dir/secrets.env"
fi
install -o root -g root -m 0644 "$source_dir/deployment/systemd/redfish-exporter.service" /etc/systemd/system/redfish-exporter.service
install -o root -g root -m 0644 "$source_dir/deployment/systemd/redfish-exporter@.service" /etc/systemd/system/redfish-exporter@.service
systemctl daemon-reload
echo "Edit $config_dir/config.yml and $config_dir/secrets.env, then run:"
echo "  systemctl enable --now redfish-exporter"
echo "For isolated SC3200/Superdome Flex instances, follow deployment/README.md."
