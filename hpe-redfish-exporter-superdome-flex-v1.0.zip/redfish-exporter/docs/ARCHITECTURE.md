# Kiến trúc và luồng xử lý

## Nguyên tắc

`/redfish/v1/` là service root; chuỗi `RedfishVersion` không quyết định mọi
resource dùng schema nào. Exporter luôn lần theo `@odata.id` và chọn dữ liệu theo
capability thực tế, không hard-code tên model hay firmware.

SC3200 và Superdome Flex dùng cùng package. Hai systemd instance là ranh giới
vận hành, không phải hai codebase.

## Luồng một lần scrape

1. `app.py` đọc YAML, đăng ký Prometheus custom collector và mở HTTP endpoint.
2. `collector.py` scrape các target song song; lỗi một RMC không làm mất metric
   của target khác.
3. `client.py` chỉ GET và chỉ theo link cùng origin để credential không rời host
   đã cấu hình.
4. Collector bắt đầu từ `Systems`, `Chassis`, `Managers` ở service root.
5. Collection ưu tiên `$expand=.`. Nếu bị từ chối hoặc response chỉ còn link,
   client fallback về collection thường và GET từng member.
6. Với từng chassis, collector chọn nguồn theo bảng capability bên dưới.

## Chọn schema theo từng metric family

| Dữ liệu | Nguồn ưu tiên | Fallback legacy |
|---|---|---|
| Temperature, fan RPM, ratio, sensor W/V | `Chassis/Sensors` | `Chassis/Thermal` |
| Fan health | `ThermalSubsystem/Fans` | `Thermal.Fans` |
| PSU health | `PowerSubsystem/PowerSupplies` | `Power.PowerSupplies` |
| PSU input/output watt | `PowerSupply/Metrics` | fields trực tiếp trong `Power.PowerSupplies` |
| Chassis input watt | `Power.PowerControl.PowerConsumedWatts` | tổng PSU input đã chọn |

Quy tắc chọn áp dụng độc lập cho từng family. Ví dụ nếu `Sensors` có nhiệt độ
nhưng không có RPM, collector vẫn lấy RPM từ `Thermal`. Nếu modern PSU có input
watt nhưng thiếu output watt, output có thể fallback sang legacy. Một family chỉ
dùng một nguồn nên không sinh duplicate series.

## Chuẩn hóa identity và label

Resource collection mới dùng `Id`; array legacy dùng `MemberId`. Helper
`_resource_id()` chuẩn hóa hai dạng thành cùng label `resource_id`, `sensor_id`
hoặc `power_supply_id`. Nếu `Name` rỗng, exporter fallback về ID.

Superdome Flex không trả `PhysicalContext` cho fan; RPM được chuẩn hóa thành
`physical_context="Fan"`. Metric name và bộ label không phụ thuộc schema, nhờ
đó dashboard không cần biết platform.

## Payload đã xác minh

### HPE Compute Scale-up Server 3200

Payload firmware đã dùng để phát triển công bố `Sensors`, `ThermalSubsystem` và
`PowerSubsystem` trên base/expansion chassis. `ExpandAll=true`, `MaxLevels=1`
giảm luồng dự kiến từ hàng trăm GET xuống vài chục GET.

- Nhiệt độ: `Sensor.ReadingType=Temperature`, đơn vị `Cel`.
- Quạt: `Rotational/RPM`; health từ collection `Fans`.
- Công suất: `Power/W`; PSU chuẩn từ `PowerSupply/Metrics`.
- Điện áp: `Voltage/V`.
- Cooling control: `Percent/%`, xuất ratio 0..1.

### HPE Superdome Flex

Payload RMC đã kiểm tra công bố Redfish 1.0.2 và legacy `Chassis/Thermal`,
`Chassis/Power`: 11 chassis object, 8 partition, 80 fan RPM, 82 fan health,
32 cặp PSU input/output watt và 34 PSU health. Hai PSU RMC có health nhưng không
có watt; exporter vẫn xuất health và không bịa giá trị 0.

Temperature dùng `MemberId` cùng tên semantic như `BMC_DIE_TEMP`, memory,
ASIC, intake/exhaust và `P*_THROT_OFFSET`. Dashboard phải dùng cả
`physical_context` lẫn `sensor_name` để phân loại đúng.

## Tách process systemd

Mô hình khuyến nghị:

- instance SC3200: port 9610, config/credential riêng;
- instance Superdome Flex: port 9611, config/credential riêng;
- vmagent scrape hai endpoint theo job riêng và thêm label tĩnh `platform`.

Tách process giúp cô lập timeout, restart và tải; nó không làm thay đổi parser
hay metric contract. Thêm RMC vào đúng config và tăng `workers` nếu cần song
song nhiều target.

## Điểm mở rộng

- Collector chuẩn mới: thêm helper nhỏ nhận JSON và trả sample; logic HTTP vẫn
  nằm ở client/collector orchestration.
- HPE OEM: chỉ dùng làm fallback khi field chuẩn thiếu; giữ nguyên metric/label.
- Cache: chỉ cache topology/URI, không cache temperature, health hoặc power.
- Label: không dùng URL, timestamp, condition message hay log text vì cardinality
  lớn; logs nên đi pipeline riêng.
