# Metric contract v0.4

Metric names and labels in this document are the public API used by Grafana,
alerts and recording rules for SC3200 and Superdome Flex. Metric names and
labels stay identical whichever Redfish schema supplies the value.

## Common labels

| Label | Meaning |
|---|---|
| `target` | Stable target name from `config.yml` |
| `system_id` | Redfish ComputerSystem `Id` |
| `chassis_id` | Redfish Chassis `Id`; empty for resources with no chassis parent |
| `resource_id` | `Id` of the health resource |
| `resource_name` | Human-readable `Name`; display only, do not use as identity |
| `sensor_id` | Sensor `Id`; legacy Thermal arrays use `MemberId` |
| `sensor_name` | Human-readable Sensor `Name` |
| `physical_context` | Redfish context such as CPU, Fan or PowerSupply; legacy RPM defaults to `Fan` |

## Metrics

| Metric | Labels | Unit / values |
|---|---|---|
| `redfish_up` | `target` | 1 success, 0 failure |
| `redfish_scrape_duration_seconds` | `target` | seconds |
| `redfish_resource_health` | `target,chassis_id,resource_type,resource_id,resource_name` | OK=1, Warning=.5, Critical=0, Unknown=-1 |
| `redfish_resource_power_state` | `target,chassis_id,resource_type,resource_id` | On=1, transitional=.5, Off=0, Unknown=-1 |
| `redfish_temperature_celsius` | `target,chassis_id,sensor_id,sensor_name,physical_context` | Celsius |
| `redfish_fan_speed_rpm` | sensor labels | RPM |
| `redfish_sensor_ratio` | sensor labels | ratio 0..1; SC3200 `AUTOFAN_ZONE_*` cooling control sensors |
| `redfish_sensor_power_watts` | sensor labels | watts |
| `redfish_sensor_voltage_volts` | sensor labels | volts |
| `redfish_chassis_power_input_watts` | `target,chassis_id` | watts |
| `redfish_power_supply_input_watts` | `target,chassis_id,power_supply_id,power_supply_name` | watts; modern Metrics or legacy PowerSupplies |
| `redfish_power_supply_output_watts` | same as PSU input | watts |
| `redfish_system_processor_count` | `target,system_id` | physical processors |
| `redfish_system_logical_processor_count` | `target,system_id` | logical processors |
| `redfish_system_memory_bytes` | `target,system_id` | bytes |
| `redfish_system_info` | `target,system_id` plus `hostname,manufacturer,model,serial_number,bios_version,system_type` | always 1 |
| `redfish_chassis_info` | `target,chassis_id` plus inventory labels | always 1 |
| `redfish_manager_info` | `target,manager_id` plus inventory labels | always 1 |

## Query examples

```promql
# Non-OK hardware while the endpoint is reachable
(redfish_resource_health < 1)
and on (target) (redfish_up == 1)
```

```promql
# Maximum temperature per chassis
max by (target, chassis_id) (redfish_temperature_celsius)
```

```promql
# Total input power for all chassis in one scale-up target
sum by (target) (redfish_chassis_power_input_watts)
```

```promql
# PSU efficiency ratio
redfish_power_supply_output_watts
/
redfish_power_supply_input_watts
```

```promql
# Join chassis inventory to chassis power
redfish_chassis_power_input_watts
  * on (target, chassis_id) group_left(model, chassis_name)
redfish_chassis_info
```
