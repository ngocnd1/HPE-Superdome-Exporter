# Payload cần lấy từ HPE RMC

## Chỉ cần gửi gì?

Gửi một file ZIP tạo bởi `tools/capture_redfish_payload.py`. Không gửi password, session token, cookie hoặc file cấu hình account.

Payload tối thiểu phải có:

| Nhóm | Resource cần có | Dùng để làm gì |
|---|---|---|
| Service root | `/redfish/v1/` | Xác định RMC công bố collection/link nào |
| Systems | collection và tất cả members | Host/partition, CPU, RAM, health, power state |
| Chassis | collection và tất cả members | Phân biệt enclosure, blade, drawer, module |
| Thermal | `Thermal`, `ThermalSubsystem`, `ThermalMetrics` nếu có | Nhiệt độ, quạt, redundancy |
| Power | `Power`, `PowerSubsystem`, `PowerSupply`, metrics nếu có | Watt, PSU, redundancy |
| Sensors | collection và tất cả members | Sensor generic trên firmware mới |
| Managers | collection và tất cả members | Model/firmware RMC và manager health |
| OEM | mọi `Oem.Hpe` nằm trong các resource trên | Phần RMC không ánh xạ sang chuẩn DMTF |

Điều quan trọng không phải giá trị serial hay IP, mà là `@odata.type`, `@odata.id`, tên property, kiểu dữ liệu, đơn vị, Status và quan hệ Links.

## Cách thu thập

Tạo account RMC chỉ có quyền đọc. Trên máy có Python 3:

```bash
python3 -m venv .venv-capture
.venv-capture/bin/pip install requests

read -s RMC_PASSWORD
export RMC_PASSWORD

.venv-capture/bin/python tools/capture_redfish_payload.py \
  --address https://RMC-IP \
  --username exporter-readonly \
  --password "$RMC_PASSWORD" \
  --insecure \
  --output rmc-payload

zip -r rmc-payload.zip rmc-payload
unset RMC_PASSWORD
```

Nếu có CA nội bộ, thay `--insecure` bằng:

```bash
--ca-file /path/internal-ca.pem
```

## Kiểm tra trước khi gửi

```bash
rg -n -i 'password|token|cookie|authorization|username|ipaddress|macaddress|serialnumber' rmc-payload
```

Các khóa có thể vẫn xuất hiện vì cần giữ schema, nhưng giá trị nhận dạng phải là `REDACTED`, rỗng hoặc không tồn tại. Mở `capture-manifest.json` và kiểm tra:

Script bỏ qua cả `LogServices` và `DebugLogs`. Một số firmware vẫn ghép
serial/service ID vào trường `Name`; vì tên sensor cần cho mapping nên phải kiểm
tra thủ công các giá trị `Name` trước khi chia sẻ payload ra ngoài nhóm quản trị.

- `truncated` phải là `false`;
- lỗi 401/403 cho nhánh hardware cần được báo lại;
- resource count không được chỉ có 1–3 file, vì như vậy crawler chưa nhìn thấy topology.

## Nếu không chạy được script

Phương án dự phòng là gửi kết quả JSON của từng URI trong bảng trên. Nhưng đừng tự chọn vài endpoint theo suy đoán: phải bắt đầu ở `/redfish/v1/` rồi lần theo `@odata.id`. Ảnh chụp màn hình không đủ để viết parser hoặc unit test.

## Sau khi nhận payload sẽ sửa ở đâu?

1. Tạo fixture tối thiểu đã khử bí mật; không commit nguyên payload production.
2. So sánh đường chuẩn với `Oem.Hpe`.
3. Nếu chuẩn đủ dữ liệu, mở rộng collector chuẩn.
4. Nếu chỉ OEM có dữ liệu, tạo `src/redfish_exporter/adapters/hpe.py` và dùng nó làm fallback.
5. Giữ nguyên metric name/labels giữa đường chuẩn và OEM để dashboard không phụ thuộc firmware.

## Chạy lại payload bằng DMTF Mockup Server

Capture dùng tên `Systems.json` để file resource và thư mục con cùng tồn tại.
Chuyển nó sang layout `Systems/index.json` mà DMTF Mockup Server yêu cầu:

```bash
python tools/capture_to_mockup.py rmc-payload rmc-mockup
./scripts/test-with-dmtf-mockup.sh rmc-mockup
```
