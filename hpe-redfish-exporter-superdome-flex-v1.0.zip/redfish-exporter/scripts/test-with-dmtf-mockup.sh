#!/usr/bin/env bash
set -euo pipefail

# Integration smoke test against the official DMTF server. By default it uses
# the repository's public-rackmount1. Pass a DSP2043 mockup directory as $1 to
# test the bladed-system dataset as well.
work_dir="${TMPDIR:-/tmp}/redfish-exporter-mockup-test"
server_dir="$work_dir/Redfish-Mockup-Server"
port="${MOCKUP_PORT:-8000}"
mockup_dir="${1:-}"

mkdir -p "$work_dir"
if [[ ! -d "$server_dir/.git" ]]; then
  git clone --depth 1 https://github.com/DMTF/Redfish-Mockup-Server.git "$server_dir"
fi
python3 -m venv "$work_dir/venv"
"$work_dir/venv/bin/pip" install -q -r "$server_dir/requirements.txt" -e "$(cd "$(dirname "$0")/.." && pwd)"

args=(-H 127.0.0.1 -p "$port")
# The DMTF server's default directory is relative to the current working
# directory, not the script location. Always pass an absolute directory.
if [[ -z "$mockup_dir" ]]; then mockup_dir="$server_dir/public-rackmount1"; fi
mockup_dir="$(cd "$mockup_dir" && pwd)"
args+=(-D "$mockup_dir")
if [[ ! -d "$mockup_dir/redfish" ]]; then args+=(-S); fi
"$work_dir/venv/bin/python" "$server_dir/redfishMockupServer.py" "${args[@]}" >"$work_dir/server.log" 2>&1 &
server_pid=$!
trap 'kill "$server_pid" 2>/dev/null || true' EXIT

for _ in {1..30}; do
  curl -fsS "http://127.0.0.1:$port/redfish/v1/" >/dev/null && break
  sleep 0.2
done
curl -fsS "http://127.0.0.1:$port/redfish/v1/" >/dev/null

export MOCKUP_PASSWORD=dummy
config="$work_dir/config.yml"
sed -e "s|__PORT__|$port|g" >"$config" <<'YAML'
listen_address: 127.0.0.1
listen_port: 19610
targets:
  - name: dmtf-mockup
    address: http://127.0.0.1:__PORT__
    username: dummy
    password_env: MOCKUP_PASSWORD
    verify_tls: false
YAML

"$work_dir/venv/bin/redfish-exporter" --config "$config" >"$work_dir/exporter.log" 2>&1 &
exporter_pid=$!
trap 'kill "$exporter_pid" "$server_pid" 2>/dev/null || true' EXIT
ready=false
for _ in {1..30}; do
  if curl -fsS http://127.0.0.1:19610/metrics | grep -q 'redfish_up{target="dmtf-mockup"} 1.0'; then
    ready=true
    break
  fi
  sleep 0.2
done
if [[ "$ready" != true ]]; then
  echo "Exporter did not complete a successful mockup scrape" >&2
  tail -30 "$work_dir/exporter.log" >&2
  exit 1
fi
metrics_file="$work_dir/metrics.txt"
curl -fsS http://127.0.0.1:19610/metrics >"$metrics_file"
for required_metric in \
  redfish_resource_health \
  redfish_temperature_celsius \
  redfish_chassis_power_input_watts; do
  if ! grep -q "^${required_metric}" "$metrics_file"; then
    echo "Required metric missing: $required_metric" >&2
    exit 1
  fi
done
# sed consumes the full stream; `head` would close the pipe early and, with
# pipefail enabled, incorrectly turn a successful large scrape into exit 2.
grep '^redfish_' "$metrics_file" | sed -n '1,40p'
