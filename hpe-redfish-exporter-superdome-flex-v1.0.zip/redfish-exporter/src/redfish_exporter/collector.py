from __future__ import annotations

import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Iterable

from prometheus_client.core import GaugeMetricFamily, InfoMetricFamily

from .client import RedfishClient
from .config import Config, Target

LOG = logging.getLogger(__name__)
HEALTH = {"OK": 1, "Warning": 0.5, "Critical": 0, "Unknown": -1}
POWER_STATE = {"On": 1, "PoweringOn": .5, "PoweringOff": .5, "Off": 0}


def _uri(obj: dict, key: str) -> str | None:
    value = obj.get(key)
    return value.get("@odata.id") if isinstance(value, dict) else None


def _text(value) -> str:
    return "" if value is None else str(value)


def _resource_id(item: dict) -> str:
    """Return the stable Redfish identity used by both schema generations.

    Newer collection resources use ``Id``.  The older embedded arrays in
    ``Chassis/Thermal`` and ``Chassis/Power`` use ``MemberId`` instead.
    Keeping this compatibility rule in one place prevents legacy fans and
    power supplies from collapsing into a single ``unknown`` time series.
    """
    return _text(item.get("Id") or item.get("MemberId") or "unknown")


def _resource_name(item: dict) -> str:
    """Return a display name without using an empty string as an identity."""
    return _text(item.get("Name") or _resource_id(item))


def _status_samples(target: str, resource_type: str, items: Iterable[dict], chassis_id: str = ""):
    """Export Health/HealthRollup from standalone or embedded resources."""
    for item in items:
        labels = [target, chassis_id, resource_type, _resource_id(item),
                  _resource_name(item)]
        status = item.get("Status") or {}
        health = status.get("Health") or status.get("HealthRollup") or "Unknown"
        yield "redfish_resource_health", labels, float(HEALTH.get(health, -1))


def _power_state_samples(target: str, resource_type: str, items: Iterable[dict], chassis_id: str = ""):
    for item in items:
        if item.get("PowerState") is not None:
            labels = [target, chassis_id, resource_type, _resource_id(item)]
            yield "redfish_resource_power_state", labels, float(POWER_STATE.get(item["PowerState"], -1))


def _sensor_samples(target: str, chassis_id: str, sensors: Iterable[dict]):
    """Map Sensor readings to explicit base units; export percent as ratio 0..1."""
    for sensor in sensors:
        reading = sensor.get("Reading")
        if reading is None:
            continue
        kind, units = sensor.get("ReadingType"), sensor.get("ReadingUnits")
        default_context = "Fan" if kind == "Rotational" and units == "RPM" else ""
        labels = [target, chassis_id, _resource_id(sensor), _resource_name(sensor),
                  _text(sensor.get("PhysicalContext") or default_context)]
        if kind == "Temperature" and units in ("Cel", "C"):
            yield "redfish_temperature_celsius", labels, float(reading)
        elif kind == "Rotational" and units == "RPM":
            yield "redfish_fan_speed_rpm", labels, float(reading)
        elif kind == "Percent" and units == "%":
            yield "redfish_sensor_ratio", labels, float(reading) / 100.0
        elif kind == "Power" and units == "W":
            yield "redfish_sensor_power_watts", labels, float(reading)
        elif kind == "Voltage" and units == "V":
            yield "redfish_sensor_voltage_volts", labels, float(reading)


def _legacy_temperature_samples(target: str, chassis_id: str, temperatures: Iterable[dict]):
    """Map legacy ``Thermal.Temperatures`` to the public sensor contract."""
    for sensor in temperatures:
        reading = sensor.get("ReadingCelsius")
        if reading is None:
            continue
        labels = [target, chassis_id, _resource_id(sensor), _resource_name(sensor),
                  _text(sensor.get("PhysicalContext"))]
        yield "redfish_temperature_celsius", labels, float(reading)


def _legacy_fan_speed_samples(target: str, chassis_id: str, fans: Iterable[dict]):
    """Map legacy ``Thermal.Fans`` RPM readings to the public contract."""
    for fan in fans:
        reading = fan.get("Reading")
        if reading is None or fan.get("ReadingUnits") != "RPM":
            continue
        labels = [target, chassis_id, _resource_id(fan), _resource_name(fan),
                  _text(fan.get("PhysicalContext") or "Fan")]
        yield "redfish_fan_speed_rpm", labels, float(reading)


def _metric_reading(value):
    """Read either a modern MetricValue object or a plain numeric value."""
    return value.get("Reading") if isinstance(value, dict) else value


def _direct_power_supply_samples(target: str, chassis_id: str, supplies: Iterable[dict]):
    """Read legacy PowerSupply fields returned inline by ``Chassis/Power``.

    Returns separate input and output lists so the caller can select one
    schema per metric family and never expose duplicate time series when a
    firmware advertises both old and new Redfish power schemas.
    """
    inputs = []
    outputs = []
    for supply in supplies:
        labels = [target, chassis_id, _resource_id(supply), _resource_name(supply)]
        input_value = supply.get("PowerInputWatts")
        output_value = supply.get("PowerOutputWatts")
        if input_value is not None:
            inputs.append(("redfish_power_supply_input_watts", labels, float(input_value)))
        if output_value is not None:
            outputs.append(("redfish_power_supply_output_watts", labels, float(output_value)))
    return inputs, outputs


class RedfishCollector:
    """Prometheus collector for SC3200 and Superdome Flex Redfish RMCs."""

    def __init__(self, config: Config):
        self.config = config

    def collect(self):
        resource_labels = ["target", "chassis_id", "resource_type", "resource_id", "resource_name"]
        sensor_labels = ["target", "chassis_id", "sensor_id", "sensor_name", "physical_context"]
        families = {
            "redfish_resource_health": GaugeMetricFamily("redfish_resource_health", "Health: OK=1 Warning=.5 Critical=0 Unknown=-1", labels=resource_labels),
            "redfish_resource_power_state": GaugeMetricFamily("redfish_resource_power_state", "Power: On=1 transition=.5 Off=0 Unknown=-1", labels=["target", "chassis_id", "resource_type", "resource_id"]),
            "redfish_temperature_celsius": GaugeMetricFamily("redfish_temperature_celsius", "Temperature sensor reading", labels=sensor_labels),
            "redfish_fan_speed_rpm": GaugeMetricFamily("redfish_fan_speed_rpm", "Fan rotational speed", labels=sensor_labels),
            "redfish_sensor_ratio": GaugeMetricFamily("redfish_sensor_ratio", "Generic percent sensor as ratio 0..1", labels=sensor_labels),
            "redfish_sensor_power_watts": GaugeMetricFamily("redfish_sensor_power_watts", "Power reported by Sensor", labels=sensor_labels),
            "redfish_sensor_voltage_volts": GaugeMetricFamily("redfish_sensor_voltage_volts", "Voltage reported by Sensor", labels=sensor_labels),
            "redfish_chassis_power_input_watts": GaugeMetricFamily("redfish_chassis_power_input_watts", "Total chassis input power", labels=["target", "chassis_id"]),
            "redfish_power_supply_input_watts": GaugeMetricFamily("redfish_power_supply_input_watts", "Power supply input", labels=["target", "chassis_id", "power_supply_id", "power_supply_name"]),
            "redfish_power_supply_output_watts": GaugeMetricFamily("redfish_power_supply_output_watts", "Power supply output", labels=["target", "chassis_id", "power_supply_id", "power_supply_name"]),
            "redfish_system_processor_count": GaugeMetricFamily("redfish_system_processor_count", "Physical processor count", labels=["target", "system_id"]),
            "redfish_system_logical_processor_count": GaugeMetricFamily("redfish_system_logical_processor_count", "Logical processor count", labels=["target", "system_id"]),
            "redfish_system_memory_bytes": GaugeMetricFamily("redfish_system_memory_bytes", "System total memory", labels=["target", "system_id"]),
            "redfish_system_info": InfoMetricFamily("redfish_system", "ComputerSystem inventory", labels=["target", "system_id"]),
            "redfish_chassis_info": InfoMetricFamily("redfish_chassis", "Chassis inventory", labels=["target", "chassis_id"]),
            "redfish_manager_info": InfoMetricFamily("redfish_manager", "Manager inventory", labels=["target", "manager_id"]),
        }
        up = GaugeMetricFamily("redfish_up", "Whether target scrape succeeded", labels=["target"])
        duration = GaugeMetricFamily("redfish_scrape_duration_seconds", "Target scrape duration", labels=["target"])
        with ThreadPoolExecutor(max_workers=min(self.config.workers, len(self.config.targets))) as pool:
            future_map = {pool.submit(self._scrape, t): (t, time.monotonic()) for t in self.config.targets}
            for future in as_completed(future_map):
                target, started = future_map[future]
                try:
                    for metric, labels, value in future.result():
                        families[metric].add_metric(labels, value)
                    up.add_metric([target.name], 1)
                except Exception as exc:
                    LOG.warning("scrape failed target=%s error=%s", target.name, exc)
                    up.add_metric([target.name], 0)
                duration.add_metric([target.name], time.monotonic() - started)
        yield from (*families.values(), up, duration)

    def _scrape(self, target: Target):
        """Discover via advertised links. Never branch on vendor/model names."""
        client = RedfishClient(target, self.config.scrape_timeout)
        root = client.get("/redfish/v1/")
        samples = []
        systems = client.members(_uri(root, "Systems")) if _uri(root, "Systems") else []
        chassis = client.members(_uri(root, "Chassis")) if _uri(root, "Chassis") else []
        managers = client.members(_uri(root, "Managers")) if _uri(root, "Managers") else []
        samples.extend(_status_samples(target.name, "system", systems))
        samples.extend(_status_samples(target.name, "manager", managers))
        samples.extend(_power_state_samples(target.name, "system", systems))

        for system in systems:
            sid = _text(system.get("Id", "unknown"))
            summary = system.get("ProcessorSummary") or {}
            samples += [
                ("redfish_system_processor_count", [target.name, sid], float(summary.get("Count", 0))),
                ("redfish_system_logical_processor_count", [target.name, sid], float(summary.get("LogicalProcessorCount", 0))),
                ("redfish_system_memory_bytes", [target.name, sid], float((system.get("MemorySummary") or {}).get("TotalSystemMemoryGiB", 0)) * 1024**3),
                ("redfish_system_info", [target.name, sid], {
                    "hostname": _text(system.get("HostName")),
                    "manufacturer": _text(system.get("Manufacturer")), "model": _text(system.get("Model")),
                    "serial_number": _text(system.get("SerialNumber")), "bios_version": _text(system.get("BiosVersion")),
                    "system_type": _text(system.get("SystemType")),
                }),
            ]
        for manager in managers:
            mid = _text(manager.get("Id", "unknown"))
            samples.append(("redfish_manager_info", [target.name, mid], {
                "manager_name": _text(manager.get("Name")), "manager_type": _text(manager.get("ManagerType")),
                "manufacturer": _text(manager.get("Manufacturer")), "model": _text(manager.get("Model")),
                "firmware_version": _text(manager.get("FirmwareVersion")),
            }))

        for ch in chassis:
            cid = _resource_id(ch)
            samples.extend(_status_samples(target.name, "chassis", [ch], cid))
            samples.extend(_power_state_samples(target.name, "chassis", [ch], cid))
            samples.append(("redfish_chassis_info", [target.name, cid], {
                "chassis_name": _text(ch.get("Name")), "chassis_type": _text(ch.get("ChassisType")),
                "manufacturer": _text(ch.get("Manufacturer")), "model": _text(ch.get("Model")),
                "serial_number": _text(ch.get("SerialNumber")), "part_number": _text(ch.get("PartNumber")),
            }))
            # Capability-based selection: SC3200 exposes standalone Sensor,
            # ThermalSubsystem and PowerSubsystem resources.  Superdome Flex
            # firmware exposes the same data in embedded Thermal/Power arrays.
            # We select a source per metric family, never by model string.
            thermal_subsystem_uri = _uri(ch, "ThermalSubsystem")
            modern_fans = []
            if thermal_subsystem_uri:
                subsystem = client.get(thermal_subsystem_uri)
                samples.extend(_status_samples(target.name, "thermal_subsystem", [subsystem], cid))
                fans_uri = _uri(subsystem, "Fans")
                modern_fans = client.members(fans_uri) if fans_uri else []
                samples.extend(_status_samples(target.name, "fan", modern_fans, cid))

            sensors_uri = _uri(ch, "Sensors")
            modern_sensor_samples = list(_sensor_samples(
                target.name, cid, client.members(sensors_uri) if sensors_uri else []
            ))
            samples.extend(modern_sensor_samples)
            modern_metric_names = {sample[0] for sample in modern_sensor_samples}

            # Only fetch/use legacy Thermal when a corresponding modern family
            # is absent.  This both reduces SC3200 GETs and prevents duplicate
            # temperature/RPM/health series on hybrid firmware.
            needs_legacy_temperature = "redfish_temperature_celsius" not in modern_metric_names
            needs_legacy_fan_speed = "redfish_fan_speed_rpm" not in modern_metric_names
            needs_legacy_fan_health = not modern_fans
            thermal_uri = _uri(ch, "Thermal")
            if thermal_uri and (
                needs_legacy_temperature or needs_legacy_fan_speed or needs_legacy_fan_health
            ):
                thermal = client.get(thermal_uri)
                legacy_fans = thermal.get("Fans", [])
                if needs_legacy_temperature:
                    samples.extend(_legacy_temperature_samples(
                        target.name, cid, thermal.get("Temperatures", [])
                    ))
                if needs_legacy_fan_speed:
                    samples.extend(_legacy_fan_speed_samples(target.name, cid, legacy_fans))
                if needs_legacy_fan_health:
                    samples.extend(_status_samples(target.name, "fan", legacy_fans, cid))

            chassis_power_watts = None
            modern_input_samples = []
            modern_output_samples = []
            modern_supplies = []
            power_subsystem_uri = _uri(ch, "PowerSubsystem")
            if power_subsystem_uri:
                subsystem = client.get(power_subsystem_uri)
                samples.extend(_status_samples(target.name, "power_subsystem", [subsystem], cid))
                supplies_uri = _uri(subsystem, "PowerSupplies")
                modern_supplies = client.members(supplies_uri) if supplies_uri else []
                samples.extend(_status_samples(target.name, "power_supply", modern_supplies, cid))
                for supply in modern_supplies:
                    labels = [target.name, cid, _resource_id(supply), _resource_name(supply)]
                    metrics_uri = _uri(supply, "Metrics")
                    if not metrics_uri:
                        continue
                    metrics = client.get(metrics_uri)
                    input_value = _metric_reading(metrics.get("InputPowerWatts"))
                    output_value = _metric_reading(metrics.get("OutputPowerWatts"))
                    if input_value is not None:
                        modern_input_samples.append((
                            "redfish_power_supply_input_watts", labels, float(input_value)
                        ))
                    if output_value is not None:
                        modern_output_samples.append((
                            "redfish_power_supply_output_watts", labels, float(output_value)
                        ))

            # Chassis/Power can coexist with PowerSubsystem: PowerControl is
            # still the preferred explicit chassis total, while inline legacy
            # PSU values are only a fallback for missing modern metric families.
            power_uri = _uri(ch, "Power")
            legacy_supplies = []
            if power_uri:
                power = client.get(power_uri)
                controls = power.get("PowerControl", [])
                if controls and controls[0].get("PowerConsumedWatts") is not None:
                    chassis_power_watts = float(controls[0]["PowerConsumedWatts"])
                legacy_supplies = power.get("PowerSupplies", [])

            if not modern_supplies:
                samples.extend(_status_samples(
                    target.name, "power_supply", legacy_supplies, cid
                ))
            legacy_input_samples, legacy_output_samples = _direct_power_supply_samples(
                target.name, cid, legacy_supplies
            )
            selected_input_samples = modern_input_samples or legacy_input_samples
            selected_output_samples = modern_output_samples or legacy_output_samples
            samples.extend(selected_input_samples)
            samples.extend(selected_output_samples)
            if chassis_power_watts is None and selected_input_samples:
                chassis_power_watts = sum(sample[2] for sample in selected_input_samples)
            if chassis_power_watts is not None:
                samples.append(("redfish_chassis_power_input_watts", [target.name, cid], chassis_power_watts))
        return samples
