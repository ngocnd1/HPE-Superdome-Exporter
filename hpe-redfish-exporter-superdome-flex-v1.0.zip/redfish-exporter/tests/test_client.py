import pytest
import requests

from redfish_exporter.client import RedfishClient
from redfish_exporter.config import Target


def test_client_retries_transport_disconnects_for_get_requests():
    target = Target("sc3200", "https://rmc.example", "monitor", "secret", False)
    client = RedfishClient(target, timeout=10)
    retry = client.session.get_adapter("https://").max_retries

    assert retry.total == 2
    assert retry.connect == 2
    assert retry.read == 2
    assert retry.status == 0
    assert retry.allowed_methods == frozenset({"GET"})


def test_members_uses_expanded_member_bodies_without_extra_gets():
    client = RedfishClient.__new__(RedfishClient)
    calls = []

    def fake_get(uri):
        calls.append(uri)
        return {"Members": [
            {"@odata.id": "/sensor/0", "Id": "0", "Reading": 41},
            {"@odata.id": "/sensor/1", "Id": "1", "Reading": 42},
        ]}

    client.get = fake_get
    result = client.members("/collection")

    assert calls == ["/collection?$expand=."]
    assert [item["Reading"] for item in result] == [41, 42]


def test_members_follows_links_when_firmware_ignores_expand():
    client = RedfishClient.__new__(RedfishClient)
    calls = []

    def fake_get(uri):
        calls.append(uri)
        if uri.endswith("$expand=."):
            return {"Members": [{"@odata.id": "/sensor/0"}, {"@odata.id": "/sensor/1"}]}
        return {"Id": uri.rsplit("/", 1)[-1]}

    client.get = fake_get
    result = client.members("/collection")

    assert calls == ["/collection?$expand=.", "/sensor/0", "/sensor/1"]
    assert [item["Id"] for item in result] == ["0", "1"]


def test_members_falls_back_when_expand_is_rejected():
    client = RedfishClient.__new__(RedfishClient)
    calls = []

    def fake_get(uri):
        calls.append(uri)
        if uri.endswith("$expand=."):
            response = requests.Response()
            response.status_code = 400
            raise requests.HTTPError(response=response)
        if uri == "/collection":
            return {"Members": [{"@odata.id": "/sensor/0"}]}
        return {"Id": "0"}

    client.get = fake_get
    assert client.members("/collection") == [{"Id": "0"}]
    assert calls == ["/collection?$expand=.", "/collection", "/sensor/0"]


def test_members_does_not_hide_authentication_errors():
    client = RedfishClient.__new__(RedfishClient)

    def fake_get(_uri):
        response = requests.Response()
        response.status_code = 401
        raise requests.HTTPError(response=response)

    client.get = fake_get
    with pytest.raises(requests.HTTPError):
        client.members("/collection")
