import os

from redfish_exporter.config import load_config


def test_load_env_password(tmp_path):
    os.environ["TEST_REDFISH_PASSWORD"] = "secret"
    p = tmp_path / "config.yml"
    p.write_text("targets:\n  - name: x\n    address: https://127.0.0.1\n    username: u\n    password_env: TEST_REDFISH_PASSWORD\n")
    cfg = load_config(str(p))
    assert cfg.targets[0].password == "secret"
    assert cfg.targets[0].verify is True
