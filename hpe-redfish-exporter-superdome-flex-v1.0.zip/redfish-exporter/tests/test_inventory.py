import redfish_exporter.collector as collector_module
from redfish_exporter.collector import RedfishCollector
from redfish_exporter.config import Config, Target


def test_system_hostname_is_exported_from_computer_system(monkeypatch):
    class FakeClient:
        def __init__(self, *_args, **_kwargs):
            pass

        def get(self, uri):
            assert uri == "/redfish/v1/"
            return {"Systems": {"@odata.id": "/redfish/v1/Systems"}}

        def members(self, uri):
            assert uri == "/redfish/v1/Systems"
            return [{
                "Id": "Partition0",
                "HostName": "sc3200-partition-01",
                "Manufacturer": "HPE",
                "Model": "Compute Scale-up Server 3200",
            }]

    monkeypatch.setattr(collector_module, "RedfishClient", FakeClient)
    target = Target("sc3200", "https://rmc.example", "monitor", "secret", False)
    config = Config("127.0.0.1", 9610, 60, 1, (target,))

    samples = RedfishCollector(config)._scrape(target)
    info = next(value for metric, _labels, value in samples if metric == "redfish_system_info")

    assert info["hostname"] == "sc3200-partition-01"
