from redfish_exporter.collector import _sensor_samples


def test_scale_up_rmc_sensor_mapping():
    """Representative, sanitized Sensor v1.8 payloads from HPE Scale-up RMC."""
    sensors = [
        {"Id": "CPU0_TEMP", "Name": "CPU0_TEMP", "Reading": 42,
         "ReadingType": "Temperature", "ReadingUnits": "Cel"},
        {"Id": "CHASSIS_FAN1", "Name": "CHASSIS_FAN1", "Reading": 10530,
         "ReadingType": "Rotational", "ReadingUnits": "RPM"},
        {"Id": "AUTOFAN_ZONE_1", "Name": "AUTOFAN_ZONE_1", "Reading": 35,
         "ReadingType": "Percent", "ReadingUnits": "%"},
        {"Id": "PSU1_PIN", "Name": "PSU1_PIN", "Reading": 517,
         "ReadingType": "Power", "ReadingUnits": "W"},
        {"Id": "P12V", "Name": "P12V", "Reading": 12.1,
         "ReadingType": "Voltage", "ReadingUnits": "V"},
        # A missing reading must not turn into zero: zero is a real value.
        {"Id": "MISSING", "Reading": None, "ReadingType": "Temperature", "ReadingUnits": "Cel"},
    ]

    samples = list(_sensor_samples("rmc", "r001u06", sensors))
    assert [sample[0] for sample in samples] == [
        "redfish_temperature_celsius",
        "redfish_fan_speed_rpm",
        "redfish_sensor_ratio",
        "redfish_sensor_power_watts",
        "redfish_sensor_voltage_volts",
    ]
    assert samples[1][2] == 10530.0
    assert samples[1][1][-1] == "Fan"
    assert samples[2][2] == 0.35
    assert samples[3][1] == ["rmc", "r001u06", "PSU1_PIN", "PSU1_PIN", ""]


def test_empty_sensor_name_falls_back_to_sensor_id():
    samples = list(_sensor_samples("rmc", "chassis-1", [{
        "Id": "TEMP_01",
        "Name": "",
        "Reading": 30,
        "ReadingType": "Temperature",
        "ReadingUnits": "Cel",
    }]))

    assert samples[0][1][2:4] == ["TEMP_01", "TEMP_01"]
