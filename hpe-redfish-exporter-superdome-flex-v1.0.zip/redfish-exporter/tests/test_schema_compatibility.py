import redfish_exporter.collector as collector_module
from redfish_exporter.collector import RedfishCollector
from redfish_exporter.config import Config, Target


class FakeClient:
    """Small advertised-link fixture; no model-name branching is involved."""

    resources = {}
    collections = {}

    def __init__(self, *_args, **_kwargs):
        pass

    def get(self, uri):
        return self.resources[uri]

    def members(self, uri):
        return self.collections.get(uri, [])


def scrape(monkeypatch, resources, collections):
    FakeClient.resources = resources
    FakeClient.collections = collections
    monkeypatch.setattr(collector_module, "RedfishClient", FakeClient)
    target = Target("rmc-test", "https://rmc.example", "monitor", "secret", False)
    config = Config("127.0.0.1", 9610, 60, 1, (target,))
    return RedfishCollector(config)._scrape(target)


def metric(samples, name):
    return [sample for sample in samples if sample[0] == name]


def test_superdome_flex_legacy_thermal_and_power(monkeypatch):
    """Legacy Thermal/Power arrays must fill the same stable metric contract."""
    chassis = {
        "Id": "enclosure-1",
        "Name": "Compute enclosure 1",
        "ChassisType": "RackMount",
        "Status": {"Health": "OK"},
        "Thermal": {"@odata.id": "/chassis/1/thermal"},
        "Power": {"@odata.id": "/chassis/1/power"},
    }
    resources = {
        "/redfish/v1/": {"Chassis": {"@odata.id": "/chassis"}},
        "/chassis/1/thermal": {
            "Temperatures": [{
                "MemberId": "0",
                "Name": "enclosure-1 P0_THROT_OFFSET",
                "PhysicalContext": "CPU",
                "ReadingCelsius": -27,
            }],
            "Fans": [
                {
                    "MemberId": "0",
                    "Name": "enclosure-1/chassis_fan0",
                    "Reading": 7625,
                    "ReadingUnits": "RPM",
                    "Status": {"Health": "OK"},
                },
                {
                    "MemberId": "1",
                    "Name": "enclosure-1/chassis_fan1",
                    "Reading": None,
                    "ReadingUnits": "RPM",
                    "Status": {"Health": "Warning"},
                },
            ],
        },
        "/chassis/1/power": {
            "PowerControl": [{"PowerConsumedWatts": 1100.5}],
            "PowerSupplies": [
                {
                    "MemberId": "0",
                    "Name": "enclosure-1/psu0",
                    "PowerInputWatts": 307,
                    "PowerOutputWatts": 279.5,
                    "Status": {"Health": "OK"},
                },
                {
                    "MemberId": "1",
                    "Name": "enclosure-1/psu1",
                    "Status": {"Health": "Warning"},
                },
            ],
        },
    }
    samples = scrape(monkeypatch, resources, {"/chassis": [chassis]})

    temperatures = metric(samples, "redfish_temperature_celsius")
    assert temperatures == [(
        "redfish_temperature_celsius",
        ["rmc-test", "enclosure-1", "0", "enclosure-1 P0_THROT_OFFSET", "CPU"],
        -27.0,
    )]

    fan_speed = metric(samples, "redfish_fan_speed_rpm")
    assert fan_speed[0][1][-1] == "Fan"
    assert fan_speed[0][2] == 7625.0

    fan_health = [sample for sample in metric(samples, "redfish_resource_health")
                  if sample[1][2] == "fan"]
    assert [sample[1][3] for sample in fan_health] == ["0", "1"]
    assert [sample[2] for sample in fan_health] == [1.0, 0.5]

    psu_health = [sample for sample in metric(samples, "redfish_resource_health")
                  if sample[1][2] == "power_supply"]
    assert [sample[1][3] for sample in psu_health] == ["0", "1"]
    assert metric(samples, "redfish_power_supply_input_watts")[0][2] == 307.0
    assert metric(samples, "redfish_power_supply_output_watts")[0][2] == 279.5
    assert metric(samples, "redfish_chassis_power_input_watts")[0][2] == 1100.5


def test_modern_schema_wins_without_duplicate_series(monkeypatch):
    """A hybrid payload must not export both modern and legacy readings."""
    chassis = {
        "Id": "chassis-1",
        "Sensors": {"@odata.id": "/chassis/1/sensors"},
        "ThermalSubsystem": {"@odata.id": "/chassis/1/thermal-subsystem"},
        "Thermal": {"@odata.id": "/chassis/1/thermal"},
        "PowerSubsystem": {"@odata.id": "/chassis/1/power-subsystem"},
        "Power": {"@odata.id": "/chassis/1/power"},
    }
    resources = {
        "/redfish/v1/": {"Chassis": {"@odata.id": "/chassis"}},
        "/chassis/1/thermal-subsystem": {
            "Id": "thermal",
            "Fans": {"@odata.id": "/chassis/1/fans"},
            "Status": {"Health": "OK"},
        },
        "/chassis/1/thermal": {
            "Temperatures": [{"MemberId": "legacy-temp", "ReadingCelsius": 99}],
            "Fans": [{
                "MemberId": "legacy-fan", "Reading": 9999, "ReadingUnits": "RPM",
                "Status": {"Health": "Critical"},
            }],
        },
        "/chassis/1/power-subsystem": {
            "Id": "power",
            "PowerSupplies": {"@odata.id": "/chassis/1/power-supplies"},
            "Status": {"Health": "OK"},
        },
        "/chassis/1/psu-modern/metrics": {
            "InputPowerWatts": {"Reading": 300},
            "OutputPowerWatts": {"Reading": 275},
        },
        "/chassis/1/power": {
            "PowerControl": [{"PowerConsumedWatts": 600}],
            "PowerSupplies": [{
                "MemberId": "legacy-psu",
                "PowerInputWatts": 999,
                "PowerOutputWatts": 888,
                "Status": {"Health": "Critical"},
            }],
        },
    }
    collections = {
        "/chassis": [chassis],
        "/chassis/1/sensors": [
            {
                "Id": "temp-modern", "Name": "Modern temperature", "Reading": 40,
                "ReadingType": "Temperature", "ReadingUnits": "Cel",
            },
            {
                "Id": "fan-modern", "Name": "Modern fan", "Reading": 7000,
                "ReadingType": "Rotational", "ReadingUnits": "RPM",
            },
        ],
        "/chassis/1/fans": [{
            "Id": "fan-modern", "Name": "Modern fan", "Status": {"Health": "OK"},
        }],
        "/chassis/1/power-supplies": [{
            "Id": "psu-modern", "Name": "Modern PSU", "Status": {"Health": "OK"},
            "Metrics": {"@odata.id": "/chassis/1/psu-modern/metrics"},
        }],
    }
    samples = scrape(monkeypatch, resources, collections)

    assert [sample[1][2] for sample in metric(samples, "redfish_temperature_celsius")] == [
        "temp-modern"
    ]
    assert [sample[1][2] for sample in metric(samples, "redfish_fan_speed_rpm")] == [
        "fan-modern"
    ]
    assert [sample[1][2] for sample in metric(samples, "redfish_power_supply_input_watts")] == [
        "psu-modern"
    ]
    assert [sample[1][2] for sample in metric(samples, "redfish_power_supply_output_watts")] == [
        "psu-modern"
    ]
    fan_health = [sample for sample in metric(samples, "redfish_resource_health")
                  if sample[1][2] == "fan"]
    psu_health = [sample for sample in metric(samples, "redfish_resource_health")
                  if sample[1][2] == "power_supply"]
    assert [sample[1][3] for sample in fan_health] == ["fan-modern"]
    assert [sample[1][3] for sample in psu_health] == ["psu-modern"]
    assert metric(samples, "redfish_chassis_power_input_watts")[0][2] == 600.0
