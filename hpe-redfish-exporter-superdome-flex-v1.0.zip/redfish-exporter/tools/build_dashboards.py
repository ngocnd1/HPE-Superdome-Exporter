#!/usr/bin/env python3
"""Generate the supported Grafana dashboard JSON files.

Keeping queries in code prevents five dashboards from drifting apart when the
metric contract changes. Generated JSON is committed so Grafana can import it
without Python or a build step.
"""
from __future__ import annotations

import json
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "grafana" / "dashboards"
DS = {"type": "victoriametrics-metrics-datasource", "uid": "${DS_VICTORIAMETRICS}"}


def target(expr, legend="", instant=False):
    return {"datasource": DS, "expr": expr, "legendFormat": legend,
            "refId": "A", "instant": instant, "range": not instant}


def panel(pid, title, kind, x, y, w, h, targets, unit="short", thresholds=None, links=None):
    defaults = {"unit": unit, "color": {"mode": "thresholds"},
                "thresholds": {"mode": "absolute", "steps": thresholds or [{"color": "green", "value": None}]}}
    if links:
        defaults["links"] = links
    return {"id": pid, "title": title, "type": kind, "datasource": DS,
            "gridPos": {"x": x, "y": y, "w": w, "h": h}, "targets": targets,
            "fieldConfig": {"defaults": defaults, "overrides": []},
            "options": {"showHeader": True, "legend": {"displayMode": "table", "placement": "bottom"},
                        "tooltip": {"mode": "multi", "sort": "desc"}}}


def variables(detail=True):
    items = [{"name": "DS_VICTORIAMETRICS", "label": "VictoriaMetrics", "type": "datasource",
              "query": "victoriametrics-metrics-datasource", "refresh": 1}]
    if detail:
        items += [
            {"name": "target", "label": "RMC target", "type": "query", "datasource": DS,
             "query": "label_values(redfish_up, target)", "definition": "label_values(redfish_up, target)",
             "refresh": 1, "multi": True, "includeAll": True, "allValue": ".*"},
            {"name": "chassis", "label": "Chassis", "type": "query", "datasource": DS,
             "query": "label_values(redfish_chassis_info{target=~\"$target\"}, chassis_id)",
             "definition": "label_values(redfish_chassis_info{target=~\"$target\"}, chassis_id)",
             "refresh": 2, "multi": True, "includeAll": True, "allValue": ".*"},
        ]
    return items


def dashboard(uid, title, description, panels, tags, detail=True):
    return {"id": None, "uid": uid, "title": title, "description": description,
            "tags": ["redfish", "victoriametrics", *tags], "timezone": "browser",
            "schemaVersion": 39, "version": 2, "editable": True, "refresh": "1m",
            "time": {"from": "now-6h", "to": "now"},
            "templating": {"list": variables(detail)}, "annotations": {"list": []},
            "panels": panels}


DETAIL_LINK = [{"title": "Open RMC overview", "url": "/d/redfish-rmc-overview/redfish-rmc-overview?var-DS_VICTORIAMETRICS=${DS_VICTORIAMETRICS}&var-target=${__field.labels.target}", "targetBlank": False}]
health_steps = [{"color": "red", "value": None}, {"color": "orange", "value": .5}, {"color": "green", "value": 1}]

dashboards = []

# Fleet: answer which RMC or chassis needs attention now.
p = [
 panel(1,"Configured targets","stat",0,0,6,4,[target("count(redfish_up)",instant=True)]),
 panel(2,"Targets up","stat",6,0,6,4,[target("sum(redfish_up)",instant=True)],thresholds=[{"color":"red","value":None},{"color":"green","value":1}]),
 panel(3,"Non-OK resources","stat",12,0,6,4,[target("count((redfish_resource_health < 1) and (redfish_resource_health >= 0))",instant=True)],thresholds=[{"color":"green","value":None},{"color":"red","value":1}]),
 panel(4,"Fleet input power","stat",18,0,6,4,[target("sum(redfish_chassis_power_input_watts)",instant=True)],"watt"),
 panel(5,"RMC availability","table",0,4,12,8,[target("redfish_up",instant=True)],links=DETAIL_LINK),
 panel(6,"Exceptions requiring action","table",12,4,12,8,[target("(redfish_resource_health < 1) and (redfish_resource_health >= 0)",instant=True)],thresholds=health_steps,links=DETAIL_LINK),
 panel(7,"Input power by target","bargauge",0,12,12,8,[target("sum by (target) (redfish_chassis_power_input_watts)","{{target}}",True)],"watt",links=DETAIL_LINK),
 panel(8,"Hottest chassis","bargauge",12,12,12,8,[target("max by (target, chassis_id) (redfish_temperature_celsius)","{{target}} / {{chassis_id}}",True)],"celsius",links=DETAIL_LINK),
]
dashboards.append(("01-redfish-fleet-overview.json", dashboard("redfish-fleet-overview","Redfish / Fleet Overview","Exception-first view across all RMC and BMC targets.",p,["fleet"],False)))

# Target overview: answer what this RMC manages and whether it is healthy.
p = [
 panel(1,"Target up","stat",0,0,4,4,[target('min(redfish_up{target=~"$target"})',instant=True)]),
 panel(2,"Non-OK resources","stat",4,0,5,4,[target('count((redfish_resource_health{target=~"$target"} < 1) and (redfish_resource_health{target=~"$target"} >= 0))',instant=True)],thresholds=[{"color":"green","value":None},{"color":"red","value":1}]),
 panel(3,"Physical CPUs","stat",9,0,5,4,[target('sum(redfish_system_processor_count{target=~"$target"})',instant=True)]),
 panel(4,"Logical CPUs","stat",14,0,5,4,[target('sum(redfish_system_logical_processor_count{target=~"$target"})',instant=True)]),
 panel(5,"Memory","stat",19,0,5,4,[target('sum(redfish_system_memory_bytes{target=~"$target"})',instant=True)],"bytes"),
 panel(6,"RMC inventory","table",0,4,12,7,[target('redfish_manager_info{target=~"$target"}',instant=True)]),
 panel(7,"System inventory","table",12,4,12,7,[target('redfish_system_info{target=~"$target"}',instant=True)]),
 panel(8,"Chassis inventory","table",0,11,24,7,[target('redfish_chassis_info{target=~"$target",chassis_id=~"$chassis"}',instant=True)]),
 panel(9,"Resource health","table",0,18,12,8,[target('redfish_resource_health{target=~"$target",chassis_id=~"$chassis"}',instant=True)],thresholds=health_steps),
 panel(10,"Input power by chassis","timeseries",12,18,12,8,[target('redfish_chassis_power_input_watts{target=~"$target",chassis_id=~"$chassis"}',"{{chassis_id}}")],"watt"),
]
dashboards.append(("02-redfish-rmc-overview.json", dashboard("redfish-rmc-overview","Redfish / RMC & System Overview","Identity, topology, capacity, health and power for selected targets.",p,["detail"])))

# Health and inventory: exact current-state tables.
p = [
 panel(1,"Current health exceptions","table",0,0,24,8,[target('(redfish_resource_health{target=~"$target",chassis_id=~"$chassis"} < 1) and (redfish_resource_health{target=~"$target",chassis_id=~"$chassis"} >= 0)',instant=True)],thresholds=health_steps),
 panel(2,"All resource health","table",0,8,12,9,[target('redfish_resource_health{target=~"$target",chassis_id=~"$chassis"}',instant=True)],thresholds=health_steps),
 panel(3,"Power states","table",12,8,12,9,[target('redfish_resource_power_state{target=~"$target",chassis_id=~"$chassis"}',instant=True)]),
 panel(4,"Chassis inventory","table",0,17,24,8,[target('redfish_chassis_info{target=~"$target",chassis_id=~"$chassis"}',instant=True)]),
]
dashboards.append(("03-redfish-health-inventory.json", dashboard("redfish-health-inventory","Redfish / Health & Inventory","Exact current health and inventory for operational triage.",p,["health","inventory"])))

# Thermal: explain hot hardware and cooling response.
p = [
 panel(1,"Maximum temperature","stat",0,0,6,4,[target('max(redfish_temperature_celsius{target=~"$target",chassis_id=~"$chassis"})',instant=True)],"celsius",[{"color":"green","value":None},{"color":"orange","value":70},{"color":"red","value":85}]),
 panel(2,"Minimum fan RPM","stat",6,0,6,4,[target('min(redfish_fan_speed_rpm{target=~"$target",chassis_id=~"$chassis"})',instant=True)],"rpm"),
 panel(3,"Fan health exceptions","stat",12,0,6,4,[target('count((redfish_resource_health{target=~"$target",chassis_id=~"$chassis",resource_type="fan"} < 1) and (redfish_resource_health{target=~"$target",chassis_id=~"$chassis",resource_type="fan"} >= 0))',instant=True)],thresholds=[{"color":"green","value":None},{"color":"red","value":1}]),
 panel(4,"Cooling health","stat",18,0,6,4,[target('min(redfish_resource_health{target=~"$target",chassis_id=~"$chassis",resource_type=~"thermal_subsystem|fan"})',instant=True)],thresholds=health_steps),
 panel(5,"Temperature trends","timeseries",0,4,24,9,[target('redfish_temperature_celsius{target=~"$target",chassis_id=~"$chassis"}',"{{chassis_id}} / {{sensor_name}}")],"celsius"),
 panel(6,"Current hottest sensors","bargauge",0,13,12,9,[target('topk(20, redfish_temperature_celsius{target=~"$target",chassis_id=~"$chassis"})',"{{chassis_id}} / {{sensor_name}}",True)],"celsius"),
 panel(7,"Fan RPM","timeseries",12,13,12,9,[target('redfish_fan_speed_rpm{target=~"$target",chassis_id=~"$chassis"}',"{{chassis_id}} / {{sensor_name}}")],"rpm"),
]
dashboards.append(("04-redfish-thermal-fans.json", dashboard("redfish-thermal-fans","Redfish / Thermal & Fans","Temperature behavior, cooling response and fan health.",p,["thermal","fans"])))

# Power: explain chassis consumption and PSU balance/efficiency.
p = [
 panel(1,"Current total input","stat",0,0,6,4,[target('sum(redfish_chassis_power_input_watts{target=~"$target",chassis_id=~"$chassis"})',instant=True)],"watt"),
 panel(2,"PSU health exceptions","stat",6,0,6,4,[target('count((redfish_resource_health{target=~"$target",chassis_id=~"$chassis",resource_type="power_supply"} < 1) and (redfish_resource_health{target=~"$target",chassis_id=~"$chassis",resource_type="power_supply"} >= 0))',instant=True)],thresholds=[{"color":"green","value":None},{"color":"red","value":1}]),
 panel(3,"Minimum PSU efficiency","stat",12,0,6,4,[target('min(redfish_power_supply_output_watts{target=~"$target",chassis_id=~"$chassis"} / redfish_power_supply_input_watts{target=~"$target",chassis_id=~"$chassis"})',instant=True)],"percentunit",[{"color":"red","value":None},{"color":"orange","value":.85},{"color":"green","value":.9}]),
 panel(4,"Power chain health","stat",18,0,6,4,[target('min(redfish_resource_health{target=~"$target",chassis_id=~"$chassis",resource_type=~"power_subsystem|power_supply"})',instant=True)],thresholds=health_steps),
 panel(5,"Chassis input power","timeseries",0,4,24,8,[target('redfish_chassis_power_input_watts{target=~"$target",chassis_id=~"$chassis"}',"{{chassis_id}}")],"watt"),
 panel(6,"PSU input power","timeseries",0,12,12,8,[target('redfish_power_supply_input_watts{target=~"$target",chassis_id=~"$chassis"}',"{{chassis_id}} / PSU {{power_supply_id}}")],"watt"),
 panel(7,"PSU output power","timeseries",12,12,12,8,[target('redfish_power_supply_output_watts{target=~"$target",chassis_id=~"$chassis"}',"{{chassis_id}} / PSU {{power_supply_id}}")],"watt"),
 panel(8,"Voltage sensors","timeseries",0,20,12,8,[target('redfish_sensor_voltage_volts{target=~"$target",chassis_id=~"$chassis"}',"{{chassis_id}} / {{sensor_name}}")],"volt"),
 panel(9,"PSU efficiency now","table",12,20,12,8,[target('redfish_power_supply_output_watts{target=~"$target",chassis_id=~"$chassis"} / redfish_power_supply_input_watts{target=~"$target",chassis_id=~"$chassis"}',"",True)],"percentunit"),
]
dashboards.append(("05-redfish-power-psu.json", dashboard("redfish-power-psu","Redfish / Power & PSU","Chassis input, PSU balance, voltage and conversion efficiency.",p,["power","psu"])))

OUT.mkdir(parents=True, exist_ok=True)
for filename, content in dashboards:
    (OUT / filename).write_text(json.dumps(content, indent=2) + "\n", encoding="utf-8")
print(f"Wrote {len(dashboards)} dashboards to {OUT}")
