#!/usr/bin/env python3
"""Capture a safe, read-only Redfish topology for exporter development.

Why this exists:
    A model name is not enough to implement an exporter. Firmware revisions can
    advertise different resource links and HPE-only fields. This tool follows
    the links that the RMC actually publishes and saves the JSON *shape* needed
    to write and test collectors.

Safety properties:
    * GET only: the script never POSTs, PATCHes, PUTs or DELETEs.
    * Same-origin only: credentials cannot follow a link to another host.
    * Sensitive branches (accounts, logs, certificates and network config) are
      skipped by default.
    * Common identity/network values are replaced while keys and JSON structure
      remain intact.

The resulting directory can be zipped and sent to an exporter maintainer. It
is also compatible with the fixture-driven test approach documented in
docs/RMC_PAYLOAD.md.
"""

from __future__ import annotations

import argparse
import json
import re
from collections import deque
from pathlib import Path
from urllib.parse import urljoin, urlparse

import requests
import urllib3


# These branches add privacy risk but do not help temperature/power/health
# collectors. Remove an entry only when a new collector explicitly needs it.
SKIP_PARTS = {
    "AccountService", "SessionService", "LogServices", "DebugLogs", "Certificates",
    "EthernetInterfaces", "NetworkProtocol", "EventService",
}

# Preserve field names and types, but replace values that identify the device
# or site. OEM sensor names and schema/type names are intentionally preserved.
SENSITIVE_KEYS = re.compile(
    r"^(Password|Token|UserName|SerialNumber|UUID|HostName|FQDN|"
    r"IPv4Addresses|IPv6Addresses|MACAddress|AssetTag|ServiceIdentification|ServiceTag)$", re.IGNORECASE
)


def redact(value, key: str = ""):
    """Recursively sanitize values without changing the payload structure."""
    if SENSITIVE_KEYS.match(key):
        if isinstance(value, list):
            return []
        return "REDACTED"
    if isinstance(value, dict):
        return {k: redact(v, k) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(v, key) for v in value]
    return value


def iter_links(value):
    """Yield every local Redfish link found anywhere in a JSON document."""
    if isinstance(value, dict):
        uri = value.get("@odata.id")
        if isinstance(uri, str):
            # URI fragments point into the current JSON document and do not
            # require a second HTTP request.
            yield uri.split("#", 1)[0]
        for child in value.values():
            yield from iter_links(child)
    elif isinstance(value, list):
        for child in value:
            yield from iter_links(child)


def output_path(root: Path, uri: str) -> Path:
    clean = uri.strip("/") or "root"
    if clean.endswith("redfish/v1"):
        clean += "/index"
    return root / f"{clean}.json"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--address", required=True, help="Example: https://RMC-IP")
    parser.add_argument("--username", required=True)
    parser.add_argument("--password", required=True)
    parser.add_argument("--output", default="rmc-payload")
    parser.add_argument("--ca-file", help="Internal CA PEM; preferred in production")
    parser.add_argument("--insecure", action="store_true", help="Disable TLS verification")
    parser.add_argument("--max-resources", type=int, default=1000)
    args = parser.parse_args()

    verify: bool | str = args.ca_file or not args.insecure
    if args.insecure:
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    base = args.address.rstrip("/") + "/"
    origin = urlparse(base).netloc
    session = requests.Session()
    session.auth = (args.username, args.password)
    session.headers.update({"Accept": "application/json", "OData-Version": "4.0"})

    destination = Path(args.output)
    destination.mkdir(parents=True, exist_ok=True)
    queue = deque(["/redfish/v1/"])
    visited: set[str] = set()
    errors: list[dict] = []

    while queue and len(visited) < args.max_resources:
        uri = queue.popleft().split("#", 1)[0]
        if not uri or uri in visited or any(part in uri for part in SKIP_PARTS):
            continue
        # Scope the crawl to hardware topology. This prevents an advertised
        # external URI or unrelated service branch from expanding the capture.
        if uri != "/redfish/v1/" and not uri.startswith(
            ("/redfish/v1/Systems", "/redfish/v1/Chassis", "/redfish/v1/Managers")
        ):
            continue
        url = urljoin(base, uri.lstrip("/"))
        if urlparse(url).netloc != origin:
            continue
        visited.add(uri)
        try:
            response = session.get(url, timeout=30, verify=verify, allow_redirects=False)
            if response.status_code != 200:
                errors.append({"uri": uri, "status": response.status_code})
                continue
            payload = response.json()
        except Exception as exc:  # Capture diagnostics, never credentials.
            errors.append({"uri": uri, "error": type(exc).__name__})
            continue

        path = output_path(destination, uri)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(redact(payload), indent=2, ensure_ascii=False), encoding="utf-8")
        for link in iter_links(payload):
            if link not in visited:
                queue.append(link)

    manifest = {
        "resource_count": len(visited),
        "truncated": bool(queue),
        "errors": errors,
        "note": "Credentials are never written; identity/network fields are redacted.",
    }
    (destination / "capture-manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    print(f"Captured {len(visited)} resources in {destination}")
    print(f"Errors: {len(errors)}; truncated: {bool(queue)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
