#!/usr/bin/env python3
"""Convert capture_redfish_payload output to DMTF Mockup Server layout.

The capture tool stores URI `/redfish/v1/Systems` as `Systems.json` so a file
and a directory with the same resource name can coexist. DMTF Mockup Server
expects `/redfish/v1/Systems/index.json`. This utility performs that mechanical
conversion without modifying the original payload.
"""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    source = args.capture.resolve()
    output = args.output.resolve()
    if source == output:
        raise SystemExit("capture and output must be different directories")
    output.mkdir(parents=True, exist_ok=True)

    for path in source.rglob("*.json"):
        relative = path.relative_to(source)
        if relative.name == "capture-manifest.json":
            continue
        if relative.name == "index.json":
            destination = output / relative
        else:
            # foo.json represents URI /foo and becomes foo/index.json.
            destination = output / relative.with_suffix("") / "index.json"
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)

    print(f"Mockup written to {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
